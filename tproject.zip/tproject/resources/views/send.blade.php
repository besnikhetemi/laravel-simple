<html>
<head></head>
<body style="background: black; color: white">
<h1>Welcome {{$name}} <br> Now your email {{$email}} is registred </h1>
</body>
</html>