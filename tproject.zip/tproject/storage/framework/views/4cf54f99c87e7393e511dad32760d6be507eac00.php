<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add New Employees</div>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <div class="alert alert-danger">
					    <?php echo e($error); ?>

					  </div>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                   <form action="saveEmplyees" method="POST">
						<?php echo csrf_field(); ?>

                   		<div class="form-group">
						    <label for="fname">First Name</label>
						    <input type="text" class="form-control" id="fname" placeholder="First Name" name="fname">
						</div>
						<div class="form-group">
						    <label for="lname">Last Name</label>
						    <input type="text" class="form-control" id="lname" placeholder="Last Name" name="lname">
						</div>
					  	<div class="form-group">
						    <label for="companyEmail">Email address</label>
						    <input type="email" class="form-control" id="email" placeholder="Email address" name="email">
					 	 </div>
					  	<div class="form-group">
						    <label for="phone">Phone</label>
						    <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone">
						</div>

					  <button type="submit" class="btn btn-primary">Submit</button>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>