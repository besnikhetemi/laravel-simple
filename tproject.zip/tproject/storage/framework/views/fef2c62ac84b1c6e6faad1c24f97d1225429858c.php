<html>
<head></head>
<body style="background: black; color: white">
<h1>Welcome <?php echo e($name); ?> <br> Now your email <?php echo e($email); ?> is registred </h1>
</body>
</html>