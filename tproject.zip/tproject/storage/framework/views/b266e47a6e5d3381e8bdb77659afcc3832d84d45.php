<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Store</div>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					 <div class="alert alert-danger">
					    <?php echo e($error); ?>

					  </div>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="card-body">
                   <form action="saveCompany" method="POST" enctype="multipart/form-data" files="true">
						<?php echo csrf_field(); ?>

                   		<div class="form-group">
						    <label for="companyName">Name</label>
						    <input type="text" class="form-control" id="companyName" placeholder="Name" name="companyName">
						</div>
					  	<div class="form-group">
						    <label for="companyEmail">Email address</label>
						    <input type="email" class="form-control" id="companyEmail" placeholder="Enter email" name="companyEmail">
					 	 </div>
					  	<div class="form-group">
						    <label for="companyWebsite">Website</label>
						    <input type="text" class="form-control" id="companyWebsite" placeholder="Website" name="companyWebsite">
						</div>
						<div class="form-group">

						    <label for="companylogo">Logo</label>
						    <input type="file" class="form-control" id="companylogo" name="companylogo">
						    <small id="passwordHelpBlock" class="form-text text-muted">Minimal Dimensions must be 100x100</small>
						</div>



					  <button type="submit" class="btn btn-primary">Submit</button>
					</form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>